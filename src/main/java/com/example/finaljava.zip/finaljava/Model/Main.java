package com.example.finaljava.Model;



import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner getInput = new Scanner(System.in);
        int maximumTicketCapacity = 0;
        int vendorCount = 0;
        int ticketCount = 0;
        int vendorRetrievalRate = 0;
        int customerCount = 0;
        int customerTicketQuantity = 0;
        int customerRetrievalRate = 0;

        // Input for maximum ticket capacity
        while (maximumTicketCapacity <= 0) {
            try {
                System.out.print(">> Enter the Maximum Ticket Capacity (positive value): ");
                maximumTicketCapacity = getInput.nextInt();
                if (maximumTicketCapacity <= 0) {
                    System.out.println("Error: Maximum Ticket Capacity must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for vendor count
        while (vendorCount <= 0) {
            try {
                System.out.print(">> Vendor \n  Enter the vendor count (positive value): ");
                vendorCount = getInput.nextInt();
                if (vendorCount <= 0) {
                    System.out.println("Error: Vendor count must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for ticket count
        while (ticketCount <= 0 || ticketCount > maximumTicketCapacity) {
            try {
                System.out.print("  Enter the tickets each vendor will create (lower than Maximum Ticket Capacity): ");
                ticketCount = getInput.nextInt();
                if (ticketCount <= 0 || ticketCount > maximumTicketCapacity) {
                    System.out.println("Error: Ticket count must be a positive integer and lower than the Maximum Ticket Capacity.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for vendor retrieval rate
        while (vendorRetrievalRate <= 0) {
            try {
                System.out.print("  Enter the vendor retrieval rate (seconds, positive value): ");
                vendorRetrievalRate = getInput.nextInt();
                if (vendorRetrievalRate <= 0) {
                    System.out.println("Error: Vendor retrieval rate must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for customer count
        while (customerCount <= 0) {
            try {
                System.out.print(">> Customer \n  Enter the customer count (positive value): ");
                customerCount = getInput.nextInt();
                if (customerCount <= 0) {
                    System.out.println("Error: Customer count must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for customer ticket quantity
        while (customerTicketQuantity <= 0) {
            try {
                System.out.print("  Enter the tickets each customer will buy (positive value): ");
                customerTicketQuantity = getInput.nextInt();
                if (customerTicketQuantity <= 0) {
                    System.out.println("Error: Customer ticket quantity must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Input for customer retrieval rate
        while (customerRetrievalRate <= 0) {
            try {
                System.out.print("  Enter the customer retrieval rate (seconds, positive value): ");
                customerRetrievalRate = getInput.nextInt();
                if (customerRetrievalRate <= 0) {
                    System.out.println("Error: Customer retrieval rate must be a positive integer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Please enter a valid integer.");
                getInput.next(); // Clear invalid input
            }
        }

        // Use the fully qualified name to avoid ambiguity
        com.example.finaljava.Model.Configuration config = new com.example.finaljava.Model.Configuration(
                maximumTicketCapacity, vendorCount, ticketCount,
                vendorRetrievalRate, customerCount, customerTicketQuantity, customerRetrievalRate
        );

        // Save configuration to JSON
        config.saveConfiguration("config.json");

        // Load configuration from JSON
        com.example.finaljava.Model.Configuration loadedConfig = com.example.finaljava.Model.Configuration.loadConfiguration("config.json");
        if (loadedConfig != null) {
            System.out.println("Loaded Configuration:");
            System.out.println("Maximum Ticket Capacity: " + loadedConfig.getMaximumTicketCapacity());
            // Print other fields as needed
        }

        getInput.close();
    }
}
